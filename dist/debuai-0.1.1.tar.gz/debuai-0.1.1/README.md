# 🐛 DebugAI

[![PyPI version](https://badge.fury.io/py/debuai.svg)](https://pypi.org/project/debuai/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![CI](https://github.com/kanhaiya-bhayana/debugai/actions/workflows/main.yml/badge.svg)](https://github.com/kanhaiya-bhayana/debugai/actions)

**AI-powered CLI tool that turns any stack trace into a root cause analysis — in seconds.**

No dashboard. No account. No SDK to integrate. Just pipe in a log and get answers.

```bash
cat production.log | debuai --ai
```

---

## Demo

<!-- Replace with your terminalizer GIF -->
https://github.com/user-attachments/assets/5771164c-865e-4c95-aff8-3cc7e2dae0f2


---

## Install

```bash
pip install debuai
```

---

## Quickstart

```bash
# Analyse a log file
debuai error.log

# Pipe from any source
cat error.log | debuai
kubectl logs my-pod | debuai
docker logs my-container | debuai

# With AI analysis
debuai error.log --ai

# Machine-readable JSON output
debuai error.log --json
debuai error.log --ai --json | jq .

# Choose your AI provider
debuai error.log --ai --provider openai
debuai error.log --ai --provider anthropic
debuai error.log --ai --provider nvidia

# Analyse the last N errors in a log
debuai error.log --top 3
```

---

## What It Does

Given a stack trace like this:

```
Traceback (most recent call last):
  File "server.py", line 10, in handle_request
    result = process_data(payload)
  File "processor.py", line 25, in process_data
    value = parse_input(raw)
  File "parser.py", line 8, in parse_input
    return int(raw)
ValueError: invalid literal for int() with base 10: 'abc'
```

DebugAI gives you this:

```
🔥 Exception Type   ValueError
📍 Failure Origin   parse_input
🔗 Execution Chain  handle_request → process_data → parse_input

🤖 AI Root Cause    The function receives a string that cannot be
                    converted to int — 'abc' is passed where a
                    numeric string is expected.

🛠 Suggested Fix    Validate input before conversion:
                    if not raw.isdigit(): raise ValueError(...)

🛡 Prevention       Add input validation at the API boundary so
                    invalid types never reach the parsing layer.

🟢 Confidence: HIGH
```

---

## Supported Languages

| Language | Detection | Parser |
|---|---|---|
| Python | `Traceback (most recent call last)` | ✅ |
| Java | `.java:` in frames | ✅ |
| Go | `goroutine` / `panic:` | ✅ |
| C# / .NET | `at Namespace.Class.Method()` | ✅ |
| Node.js | `.js:` in frames | ✅ |

Language is auto-detected — no `--lang` flag needed.

---

## AI Providers

DebugAI works with whichever key you already have. Set one environment variable and it just works.

```bash
export OPENAI_API_KEY=...       # Uses gpt-4o-mini
export ANTHROPIC_API_KEY=...    # Uses claude-haiku
export NVIDIA_API_KEY=...       # Uses NVIDIA inference
```

Auto-detection order: **OpenAI → Anthropic → NVIDIA**. Override with `--provider`.

---

## JSON Output

The `--json` flag outputs clean, pipeable JSON — no Rich formatting, no colour codes.

```bash
debuai error.log --ai --json
```

```json
{
  "exception": "ValueError",
  "failure_origin": "parse_input",
  "execution_chain": ["handle_request", "process_data", "parse_input"],
  "source_file": "parser.py",
  "language": "python",
  "ai": {
    "root_cause": "...",
    "fix": "...",
    "prevention": "...",
    "confidence": "high"
  }
}
```

Pipe into `jq`, Slack bots, Jira integrations, or CI pipelines.

---

## CI / CD Integration

Add DebugAI to your GitHub Actions workflow to get AI analysis on every failed build:

```yaml
- name: Analyse failure
  if: failure()
  run: |
    pip install debuai
    cat logs/error.log | debuai --ai --json
  env:
    OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
```

---

## Setup for Development

```bash
git clone https://github.com/kanhaiya-bhayana/debugai.git
cd debugai
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows
pip install -e ".[dev]"
```

**Run tests:**
```bash
python -m pytest tests/ -v
```

**Set your API key:**
```bash
export OPENAI_API_KEY=your_key_here
```

---

## Project Structure

```
debugai/
├── parser/
│   ├── python.py        # Python traceback parser
│   ├── java.py          # Java / Spring parser
│   ├── go.py            # Go panic parser
│   ├── csharp.py        # C# / .NET parser
│   ├── node.py          # Node.js parser
│   └── registry.py      # Language auto-detection router
├── providers/
│   ├── openai_provider.py
│   ├── anthropic_provider.py
│   └── nvidia.py
├── analyzer.py          # Core extraction logic
├── ai_analyzer.py       # Provider selection + AI orchestration
└── cli.py               # Typer CLI entry point
tests/
├── test_parsers.py      # 50 parser tests
├── test_analyzer.py     # 28 analyzer tests
└── test_safeguards.py   # 13 edge case + safeguard tests
```

---

## Roadmap

- [x] Python, Java, Go, C#, Node.js parsers
- [x] Multi-provider AI backend (OpenAI, Anthropic, NVIDIA)
- [x] Structured JSON output
- [x] CI/CD pipeline
- [x] PyPI publish
- [ ] GitHub issue search — link traces to known issues automatically
- [ ] Kubernetes / Docker log stream support
- [ ] VS Code extension
- [ ] Web UI for team sharing

---

## Contributing

Contributions are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a PR.

```bash
# Run the full test suite before submitting
python -m pytest tests/ -v
```

---

## License

MIT — see [LICENSE](LICENSE) for details.

---

<p align="center">
  Built with ❤️ for developers who are tired of Googling stack traces.
</p>
